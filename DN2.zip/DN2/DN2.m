clc;
clear all;

fid = fopen('velikost_Nx_Ny.txt', 'r');

line1 = fgetl(fid);   % "Nx = 1481"
line2 = fgetl(fid);   % "Ny = 961"

fclose(fid);

Nx = sscanf(line1, 'Nx = %d');
Ny = sscanf(line2, 'Ny = %d');

fprintf('Nx = %d, Ny = %d\n\n', Nx, Ny);


vozlisca_file = 'vozlisca_temperature_dn2_4.txt';

vozlisca_data = readmatrix(vozlisca_file, ...
    'NumHeaderLines', 4, ...
    'Delimiter', ',');

x_nodes = vozlisca_data(:,1);
y_nodes = vozlisca_data(:,2);
T_nodes = vozlisca_data(:,3);

Nv = length(x_nodes);

fprintf('Število vozlišč Nv = %d\n\n', Nv);
disp('Prvih 5 vozlišč [x  y  T]:');
disp([x_nodes(1:5), y_nodes(1:5), T_nodes(1:5)]);

celice_file = 'celice_dn2_4.txt';

cells = readmatrix(celice_file, ...
    'NumHeaderLines', 2, ...
    'Delimiter', ',');

pt_id1 = cells(:,1);
pt_id2 = cells(:,2);
pt_id3 = cells(:,3);
pt_id4 = cells(:,4);

Nc = size(cells, 1);

fprintf('Število celic Nc = %d\n\n', Nc);
disp('Prve 3 celice [pt1  pt2  pt3  pt4]:');
disp(cells(1:3, :));

xq = 0.403;
yq = 0.503;
fprintf('\n(xq, yq) = (%.3f, %.3f)\n\n', xq, yq);

tic;
F_scatt = scatteredInterpolant(x_nodes, y_nodes, T_nodes, ...
                               'linear', 'none');
T_scatt = F_scatt(xq, yq);
time_scatt = toc;

fprintf('Metoda 1 — scatteredInterpolant:\n');
fprintf('  T(%.3f, %.3f) = %.10f\n', xq, yq, T_scatt);
fprintf('  Čas izračuna: %.6f s\n\n', time_scatt);


x_unique = unique(x_nodes);
y_unique = unique(y_nodes);

[~, ix] = ismember(x_nodes, x_unique);
[~, iy] = ismember(y_nodes, y_unique);


T_grid = accumarray([iy, ix], T_nodes, [Ny, Nx], @mean, NaN);

tic;

F_grid = griddedInterpolant({y_unique, x_unique}, T_grid, ...
                            'linear', 'none');

T_gridint = F_grid(yq, xq);  
time_grid = toc;

fprintf('Metoda 2 – griddedInterpolant:\n');
fprintf('  T(%.3f, %.3f) = %.10f\n', xq, yq, T_gridint);
fprintf('  čas: %.6f s\n\n', time_grid);

tic;
T_bilin = bilinear_interpolation_cells_simple(xq, yq, ...
    x_nodes, y_nodes, T_nodes, ...
    pt_id1, pt_id2, pt_id3, pt_id4);
time_bilin = toc;



fprintf('Metoda 3 – bilinearna interpolacija po celicah:\n');
fprintf('  T(%.3f, %.3f) = %.10f\n', xq, yq, T_bilin);
fprintf('  čas: %.6f s\n\n', time_bilin);

function Txy = bilinear_interpolation_cells_simple(xq, yq, ...
    x_nodes, y_nodes, T_nodes, ...
    pt_id1, pt_id2, pt_id3, pt_id4)

Txy = NaN;

Nc = numel(pt_id1);

for ic = 1:Nc
    id1 = pt_id1(ic);
    id2 = pt_id2(ic);
    id3 = pt_id3(ic);
    id4 = pt_id4(ic);

    x1 = x_nodes(id1); y1 = y_nodes(id1); T1 = T_nodes(id1);
    x2 = x_nodes(id2); y2 = y_nodes(id2); T2 = T_nodes(id2);
    x3 = x_nodes(id3); y3 = y_nodes(id3); T3 = T_nodes(id3);
    x4 = x_nodes(id4); y4 = y_nodes(id4); T4 = T_nodes(id4);

    xs = [x1 x2 x3 x4];
    ys = [y1 y2 y3 y4];
    Ts = [T1 T2 T3 T4];

    xmin = min(xs); xmax = max(xs);
    ymin = min(ys); ymax = max(ys);

    if xq >= xmin && xq <= xmax && yq >= ymin && yq <= ymax
        idxBL = find(xs == xmin & ys == ymin, 1);
        idxBR = find(xs == xmax & ys == ymin, 1);
        idxTR = find(xs == xmax & ys == ymax, 1);
        idxTL = find(xs == xmin & ys == ymax, 1);

        T11 = Ts(idxBL);
        T21 = Ts(idxBR);
        T22 = Ts(idxTR);
        T12 = Ts(idxTL);

        u = (xq - xmin)/(xmax - xmin);
        v = (yq - ymin)/(ymax - ymin);

        Txy = (1-u)*(1-v)*T11 + u*(1-v)*T21 + u*v*T22 + (1-u)*v*T12;
        return
    end
end
end


[Tmax, idx_max] = max(T_nodes);
x_max = x_nodes(idx_max);
y_max = y_nodes(idx_max);

fprintf('Največja temperatura v mreži:\n');
fprintf('  Tmax = %.10f\n', Tmax);
fprintf('  Koordinate vozlišča: (x, y) = (%.10f, %.10f)\n', x_max, y_max);




